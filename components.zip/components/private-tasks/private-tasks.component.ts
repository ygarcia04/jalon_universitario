import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-private-tasks',
  templateUrl: './private-tasks.component.html',
  styleUrls: ['./private-tasks.component.css']
})
export class PrivateTasksComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
