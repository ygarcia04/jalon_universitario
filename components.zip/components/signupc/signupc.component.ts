import { Component, OnInit } from '@angular/core';
import { AuthService } from "../../services/auth.service";
//para redireccionar
import { Router } from "@angular/router";
import swal from 'sweetalert';
import { resetState } from 'sweetalert/typings/modules/state';

@Component({
  selector: 'app-signupc',
  templateUrl: './signupc.component.html',
  styleUrls: ['./signupc.component.css']
})
export class SignupcComponent implements OnInit {
  user ={
    email:'',
    password:'',
    direccion:'',
    nombres:'',
    apellidos:'',
    numeroCuenta:''

  }

  constructor() { }

  ngOnInit(): void {
  }

}
